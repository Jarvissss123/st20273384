<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About RentMyCaravan.io</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>About RentMyCaravan.io</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="register.php">Register</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <section>
            <h2>About RentMyCaravan.io</h2>
            <p>RentMyCaravan.io is a platform for local residents and businesses to advertise their caravans that need to be rented.</p>
        </section>
        <section>
            <h2>About the Developer</h2>
            <p>This website was developed by [Your Name].</p>
        </section>
    </main>
    
    <footer>
        <p>&copy; 2024 RentMyCaravan.io. All rights reserved.</p>
    </footer>
</body>
</html>
