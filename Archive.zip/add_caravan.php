<!-- Add caravan form HTML -->
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Form validation
    $caravan_name = $_POST["caravan_name"];
    $description = $_POST["description"];
    // Add more validation as needed

    // Include database connection
    include 'db_connect.php';

    // Insert new caravan into the database
    $sql_insert_caravan = "INSERT INTO caravans (caravan_name, description) VALUES ('$caravan_name', '$description')";

    if ($conn->query($sql_insert_caravan) === TRUE) {
        echo "Caravan added successfully!";
    } else {
        echo "Error: " . $sql_insert_caravan . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
